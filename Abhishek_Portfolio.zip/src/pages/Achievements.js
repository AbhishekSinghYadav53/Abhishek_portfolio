import React from "react";

export default function Achievements() {
  return (
    <div className="p-10">
      <h2 className="text-2xl font-bold mb-6">Certifications & Achievements</h2>
      <ul className="list-disc ml-6 space-y-2">
        <li>1st prize in intra-college hackathon at KIT (2023)</li>
        <li>Top 5% rank holder in diploma batch</li>
        <li>React.js Development – Udemy</li>
        <li>UI/UX Designing Fundamentals – Udemy</li>
      </ul>
    </div>
  );
}