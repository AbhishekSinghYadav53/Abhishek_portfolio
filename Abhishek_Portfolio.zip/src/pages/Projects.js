import React from "react";

export default function Projects() {
  return (
    <div className="p-10">
      <h2 className="text-2xl font-bold mb-6">Projects</h2>
      <ul className="space-y-4">
        <li>
          <strong>Online Food Ordering System</strong> – React.js, Node.js, MongoDB<br />
          Role: UI & Frontend Developer
        </li>
        <li>
          <strong>Student Management System</strong> – Java, MySQL<br />
          Role: Backend logic and DB design
        </li>
        <li>
          <strong>Personal Portfolio Website</strong> – HTML, CSS, JavaScript<br />
          Role: Designer & Developer
        </li>
      </ul>
    </div>
  );
}