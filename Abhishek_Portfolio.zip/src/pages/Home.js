import React from "react";
import profile from "../assets/profile.jpg";
import resume from "../assets/Abhishek_Singh_Yadav_Resume.pdf";

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center py-20">
      <img src={profile} alt="Abhishek" className="rounded-full w-40 h-40 mb-4 shadow-lg" />
      <h1 className="text-3xl font-bold mb-2">Abhishek Singh Yadav</h1>
      <p className="text-lg text-gray-300 mb-6">Computer Science Student | Developer | UI/UX Designer</p>
      <a href={resume} download className="bg-blue-500 px-4 py-2 rounded hover:bg-blue-600">
        Download Resume
      </a>
    </div>
  );
}