import React from "react";

export default function Contact() {
  return (
    <div className="p-10">
      <h2 className="text-2xl font-bold mb-6">Contact</h2>
      <p>Email: abhisheksinghyadav821@gmail.com</p>
      <p>Phone: 8318637253</p>
      <p>Location: Kanpur, UP</p>
    </div>
  );
}