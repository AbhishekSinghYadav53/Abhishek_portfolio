import React from "react";

export default function Experience() {
  return (
    <div className="p-10">
      <h2 className="text-2xl font-bold mb-6">Internship Experience & Skills</h2>
      <p><strong>Software Engineering Intern</strong>, Wipro (Dec 2024 - Jan 2025)</p>
      <ul className="list-disc ml-6 mb-4">
        <li>Assisted in automation testing and backend optimization</li>
        <li>Participated in Agile meetings and fixed internal tool bugs</li>
      </ul>
      <p><strong>Frontend Developer Intern</strong>, Qual Digiln Software Solutions (June 2024)</p>
      <ul className="list-disc ml-6 mb-4">
        <li>Developed UI with React.js and contributed to redesigning a website</li>
        <li>Enhanced UX working closely with the UI/UX team</li>
      </ul>
      <p className="mt-6"><strong>Technical Skills:</strong> C++, JavaScript, HTML5, CSS3, React.js, Bootstrap, Git, Figma</p>
    </div>
  );
}